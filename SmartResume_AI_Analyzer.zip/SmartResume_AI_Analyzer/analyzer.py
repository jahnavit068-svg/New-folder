import re
from io import BytesIO

# A small editable vocabulary for a student-focused resume analyzer.
SKILLS = [
    "python", "java", "c", "c++", "javascript", "typescript", "html", "css",
    "react", "node.js", "flask", "django", "sql", "mysql", "sqlite", "mongodb",
    "machine learning", "deep learning", "natural language processing", "nlp",
    "data analysis", "data analytics", "pandas", "numpy", "scikit-learn",
    "tensorflow", "pytorch", "excel", "power bi", "tableau", "statistics",
    "communication", "teamwork", "problem solving", "git", "github", "linux",
    "aws", "azure", "cloud computing", "rest api", "api", "docker",
    "cybersecurity", "networking", "internet of things", "iot", "data structures",
    "algorithms", "object-oriented programming", "oop", "software testing",
    "agile", "project management"
]

def normalize(text):
    return re.sub(r"\s+", " ", text.lower()).strip()

def find_skills(text):
    normalized = normalize(text)
    found = []
    for skill in SKILLS:
        pattern = r"(?<![a-z0-9])" + re.escape(skill) + r"(?![a-z0-9])"
        if re.search(pattern, normalized):
            found.append(skill)
    return sorted(set(found))

def extract_text_from_file(file_storage, filename):
    extension = filename.rsplit(".", 1)[1].lower()
    raw = file_storage.read()
    if extension == "txt":
        return raw.decode("utf-8", errors="ignore")
    if extension == "pdf":
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("Install dependencies using: pip install -r requirements.txt") from exc
        reader = PdfReader(BytesIO(raw))
        pages = []
        for page in reader.pages:
            pages.append(page.extract_text() or "")
        return "\n".join(pages)
    raise ValueError("Unsupported file type")

def analyze_resume(resume_text, job_description):
    resume_skills = find_skills(resume_text)
    job_skills = find_skills(job_description)
    matched = sorted(set(resume_skills) & set(job_skills))
    missing = sorted(set(job_skills) - set(resume_skills))
    # If the job description contains no recognized skills, avoid misleading percentages.
    score = round((len(matched) / len(set(job_skills))) * 100) if job_skills else 0

    suggestions = []
    if missing:
        suggestions.append("If you genuinely have these skills, add them to the relevant Skills or Project section: " + ", ".join(missing[:8]) + ".")
    if not re.search(r"\b(project|projects)\b", resume_text, re.I):
        suggestions.append("Consider adding 1–3 relevant academic or personal projects with your role and measurable outcomes.")
    if not re.search(r"\b(internship|internships|experience|work experience)\b", resume_text, re.I):
        suggestions.append("If applicable, include internships, volunteering, coursework, or practical experience.")
    if not re.search(r"\b(education|degree|b\.?tech|bachelor|university|college)\b", resume_text, re.I):
        suggestions.append("Make sure your Education section clearly lists your degree, college, and graduation year.")
    if not suggestions:
        suggestions.append("Keep the resume concise, tailor project bullets to the job, and verify all dates and contact details.")

    return {
        "score": score,
        "resume_skills": resume_skills,
        "job_skills": job_skills,
        "matched_skills": matched,
        "missing_skills": missing,
        "job_skill_count": len(set(job_skills)),
        "resume_skill_count": len(resume_skills),
        "suggestions": suggestions,
        "no_job_skills": not bool(job_skills),
    }
