import os
import re
from collections import Counter
from flask import Flask, render_template, request, flash
from werkzeug.utils import secure_filename
from analyzer import analyze_resume, extract_text_from_file

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"pdf", "txt"}

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-for-production")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    resume_text = ""
    job_description = ""
    if request.method == "POST":
        job_description = request.form.get("job_description", "").strip()
        pasted_text = request.form.get("resume_text", "").strip()
        uploaded = request.files.get("resume_file")

        if uploaded and uploaded.filename:
            if not allowed_file(uploaded.filename):
                flash("Please upload a PDF or TXT file only.", "error")
                return render_template("index.html", result=None)
            safe_name = secure_filename(uploaded.filename)
            # Process in memory where possible; do not retain uploaded resumes.
            try:
                resume_text = extract_text_from_file(uploaded, safe_name)
            except Exception as exc:
                flash(f"Could not read that file. Try a text-based PDF or TXT file. Details: {exc}", "error")
                return render_template("index.html", result=None)
        else:
            resume_text = pasted_text

        if not resume_text:
            flash("Upload a resume file or paste your resume text.", "error")
        elif not job_description:
            flash("Please paste the job description to compare against.", "error")
        else:
            result = analyze_resume(resume_text, job_description)

    return render_template("index.html", result=result)

@app.errorhandler(413)
def too_large(_error):
    flash("File is too large. Maximum upload size is 5 MB.", "error")
    return render_template("index.html", result=None), 413

if __name__ == "__main__":
    app.run(debug=True)
